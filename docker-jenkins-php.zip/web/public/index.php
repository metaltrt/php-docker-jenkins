<?php

require 'config.php';
require 'functions.php';

run();
